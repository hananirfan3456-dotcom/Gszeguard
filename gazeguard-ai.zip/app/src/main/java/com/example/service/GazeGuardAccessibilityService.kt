package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.api.GeminiClient
import com.example.data.BlockLog
import com.example.data.DatabaseProvider
import kotlinx.coroutines.*

class GazeGuardAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var scanJob: Job? = null
    private var isAnalyzing = false
    
    private var activePackageName: String = "com.android.chrome"
    private var activeAppName: String = "Chrome Browser"

    companion object {
        private const val TAG = "GazeGuardService"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "GazeGuard Active Monitoring Service Connected!")
        startScanningLoop()
    }

    private fun startScanningLoop() {
        scanJob?.cancel()
        scanJob = serviceScope.launch {
            while (isActive) {
                val prefs = getSharedPreferences("gazeguard_prefs", MODE_PRIVATE)
                val isShieldActive = prefs.getBoolean("shield_enabled", false)
                val interval = prefs.getLong("scan_interval_ms", 3000L)

                if (isShieldActive) {
                    captureAndAnalyzeScreen()
                }
                delay(interval)
            }
        }
    }

    private fun captureAndAnalyzeScreen() {
        if (isAnalyzing) return
        isAnalyzing = true

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val executor = ContextCompat.getMainExecutor(this)
            try {
                takeScreenshot(
                    Display.DEFAULT_DISPLAY,
                    executor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(screenshotResult: ScreenshotResult) {
                            serviceScope.launch(Dispatchers.IO) {
                                try {
                                    val hardwareBuffer = screenshotResult.hardwareBuffer
                                    val colorSpace = screenshotResult.colorSpace
                                    val bitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
                                    hardwareBuffer.close() // Crucial: release immediately to avoid native memory leaks

                                    if (bitmap != null) {
                                        incrementScanCount()
                                        val result = GeminiClient.analyzeScreenshot(bitmap)
                                        if (result.detected) {
                                            triggerBlockAction(result.reason, result.confidence)
                                        }
                                    }
                                } catch (e: Exception) {
                                    Log.e(TAG, "Error processing screenshot: ${e.message}")
                                } finally {
                                    isAnalyzing = false
                                }
                            }
                        }

                        override fun onFailure(errorCode: Int) {
                            Log.e(TAG, "Failed to capture system screenshot. Code: $errorCode")
                            isAnalyzing = false
                        }
                    }
                )
            } catch (e: Exception) {
                Log.e(TAG, "Failed to initiate takeScreenshot: ${e.message}")
                isAnalyzing = false
            }
        } else {
            isAnalyzing = false
        }
    }

    private fun triggerBlockAction(reason: String, confidence: Double) {
        serviceScope.launch(Dispatchers.Main) {
            // Instantly go home to exit the current offensive screen
            performGlobalAction(GLOBAL_ACTION_HOME)

            // Alert the user
            Toast.makeText(
                applicationContext,
                "🛡️ GazeGuard AI: Unwanted content shielded!",
                Toast.LENGTH_LONG
            ).show()

            // Save log into Room database on IO thread
            serviceScope.launch(Dispatchers.IO) {
                try {
                    val repository = DatabaseProvider.getRepository(applicationContext)
                    repository.insert(
                        BlockLog(
                            appPackage = activePackageName,
                            appName = activeAppName,
                            reason = reason,
                            confidence = confidence
                        )
                    )
                    incrementBlockedCount()
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to insert block log into database: ${e.message}")
                }
            }
        }
    }

    private fun incrementScanCount() {
        val prefs = getSharedPreferences("gazeguard_prefs", MODE_PRIVATE)
        val count = prefs.getInt("total_scans", 0)
        prefs.edit().putInt("total_scans", count + 1).apply()
    }

    private fun incrementBlockedCount() {
        val prefs = getSharedPreferences("gazeguard_prefs", MODE_PRIVATE)
        val count = prefs.getInt("total_blocks", 0)
        prefs.edit().putInt("total_blocks", count + 1).apply()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString()
            val myPackage = packageName?.startsWith("com.aistudio.gazeguard") ?: false
            if (packageName != null && !myPackage && packageName != "com.example") {
                activePackageName = packageName
                activeAppName = getAppNameFromPackage(packageName)
            }
        }
    }

    private fun getAppNameFromPackage(packageName: String): String {
        return try {
            val pm = packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            packageName.substringAfterLast(".")
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "GazeGuard Service Interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        scanJob?.cancel()
        serviceScope.cancel()
    }
}
