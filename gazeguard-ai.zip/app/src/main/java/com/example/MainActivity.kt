package com.example

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BlockLog
import com.example.data.DatabaseProvider
import com.example.service.GazeGuardAccessibilityService
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = SlateBackground
                ) { innerPadding ->
                    GazeGuardDashboard(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun GazeGuardDashboard(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    // Shared Preferences states
    val prefs = remember { context.getSharedPreferences("gazeguard_prefs", Context.MODE_PRIVATE) }
    var shieldEnabled by remember { mutableStateOf(prefs.getBoolean("shield_enabled", false)) }
    var scanIntervalMs by remember { mutableStateOf(prefs.getLong("scan_interval_ms", 3000L)) }
    var totalScans by remember { mutableStateOf(prefs.getInt("total_scans", 0)) }
    var totalBlocks by remember { mutableStateOf(prefs.getInt("total_blocks", 0)) }

    // Database states
    val repository = remember { DatabaseProvider.getRepository(context) }
    val blockLogs by repository.allLogs.collectAsState(initial = emptyList())

    // Service settings verification
    var isServiceEnabled by remember { mutableStateOf(isAccessibilityServiceEnabled(context)) }

    // Live update checker for service status and background numbers
    LaunchedEffect(Unit) {
        while (true) {
            isServiceEnabled = isAccessibilityServiceEnabled(context)
            totalScans = prefs.getInt("total_scans", 0)
            totalBlocks = prefs.getInt("total_blocks", 0)
            delay(1500) // Poll stats and status every 1.5 seconds
        }
    }

    // Interactive Simulator States
    var selectedSimType by remember { mutableStateOf("unsafe") } // "safe" or "unsafe"
    var isSimulating by remember { mutableStateOf(false) }
    val simulationLogs = remember { mutableStateListOf<String>() }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp)
    ) {
        // 1. Title Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "GazeGuard AI",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextLight
                    )
                    Text(
                        text = "Active Screen Guard System",
                        fontSize = 14.sp,
                        color = TextMuted
                    )
                }
                
                // Pulsing light
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(if (shieldEnabled && isServiceEnabled) GreenActive.copy(alpha = 0.2f) else AlertRed.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(if (shieldEnabled && isServiceEnabled) GreenActive else AlertRed)
                    )
                }
            }
        }

        // 2. Hero Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SlateCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_guard_hero),
                        contentDescription = "Shield Hero Image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    
                    // Dark Overlay Gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                                )
                            )
                    )

                    // Text overlay
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Shield Enabled",
                            color = GuardBlue,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "AI Gaze Eye Protection",
                            color = TextLight,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 3. Accessibility Service Configuration State Card
        item {
            val cardBg = if (isServiceEnabled) SlateCard else AlertRed.copy(alpha = 0.15f)
            val borderBrush = if (isServiceEnabled) Color.Transparent else AlertRed

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, borderBrush, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isServiceEnabled) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = "Status Icon",
                                tint = if (isServiceEnabled) GreenActive else AlertRed,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Accessibility Service",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextLight
                                )
                                Text(
                                    text = if (isServiceEnabled) "Active and Connected" else "Inactive - Action Required",
                                    fontSize = 13.sp,
                                    color = if (isServiceEnabled) GreenActive else AlertRed
                                )
                            }
                        }
                        
                        if (!isServiceEnabled) {
                            Button(
                                onClick = {
                                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    context.startActivity(intent)
                                    Toast.makeText(context, "Turn on GazeGuard AI in Accessibility settings", Toast.LENGTH_LONG).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("enable_accessibility_button")
                            ) {
                                Text("Enable", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (!isServiceEnabled) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "GazeGuard requires Accessibility permissions to safely scan your active screen and execute the closing action when unwanted content appears. Tap 'Enable', locate GazeGuard, and toggle it on.",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        // 4. Main Toggle Shield Switch
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SlateCard)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (shieldEnabled) GuardBlue.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (shieldEnabled) Icons.Default.Shield else Icons.Default.ShieldMoon,
                                contentDescription = "Shield Icon",
                                tint = if (shieldEnabled) GuardBlue else Color.Gray,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Active AI Gaze Shield",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextLight
                            )
                            Text(
                                text = if (shieldEnabled) "Actively guarding your sight" else "Shield is sleeping",
                                fontSize = 13.sp,
                                color = if (shieldEnabled) GuardBlue else TextMuted
                            )
                        }
                    }

                    Switch(
                        checked = shieldEnabled,
                        onCheckedChange = { isChecked ->
                            shieldEnabled = isChecked
                            prefs.edit().putBoolean("shield_enabled", isChecked).apply()
                            Toast.makeText(
                                context,
                                if (isChecked) "AI Active Shield Activated!" else "Shield deactivated.",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = GuardBlue,
                            checkedTrackColor = GuardBlue.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.testTag("shield_toggle")
                    )
                }
            }
        }

        // 5. Grid Statistics
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Scanned Screens Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateCard)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(
                            imageVector = Icons.Default.Radar,
                            contentDescription = "Radar Icon",
                            tint = GuardBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Scanned Screens", fontSize = 12.sp, color = TextMuted)
                        Text(
                            text = "$totalScans",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextLight
                        )
                    }
                }

                // Interventions Card
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateCard)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Icon(
                            imageVector = Icons.Default.Block,
                            contentDescription = "Block Icon",
                            tint = AlertRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Blocked Interventions", fontSize = 12.sp, color = TextMuted)
                        Text(
                            text = "$totalBlocks",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextLight
                        )
                    }
                }
            }
        }

        // 6. Scanning Speed/Interval Slider
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SlateCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Scanning Cycle Speed",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextLight
                        )
                        Text(
                            text = "${scanIntervalMs / 1000.0}s",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = GuardBlue
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Slider(
                        value = scanIntervalMs.toFloat(),
                        onValueChange = { newValue ->
                            scanIntervalMs = newValue.toLong()
                            prefs.edit().putLong("scan_interval_ms", scanIntervalMs).apply()
                        },
                        valueRange = 1000f..5000f,
                        steps = 3,
                        colors = SliderDefaults.colors(
                            thumbColor = GuardBlue,
                            activeTrackColor = GuardBlue,
                            inactiveTrackColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("speed_slider")
                    )
                    
                    Text(
                        text = "Continuous scans run on background cycles. Faster cycles (1.0s) provide near-instantaneous protection but will increase battery usage.",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // 7. Interactive Guard Simulator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SlateCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Shield Simulator (Instant Test)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextLight
                    )
                    Text(
                        text = "Experience how GazeGuard works in millisecond real-time by simulating a live screen content check.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Safe Option Button
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selectedSimType == "safe") GuardBlue.copy(alpha = 0.2f) else SlateBackground)
                                .border(
                                    width = 1.dp,
                                    color = if (selectedSimType == "safe") GuardBlue else Color.Transparent,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedSimType = "safe" }
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "Cars Feed (Safe)",
                                color = if (selectedSimType == "safe") GuardBlue else TextLight,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }

                        // Unsafe Option Button
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selectedSimType == "unsafe") AlertRed.copy(alpha = 0.2f) else SlateBackground)
                                .border(
                                    width = 1.dp,
                                    color = if (selectedSimType == "unsafe") AlertRed else Color.Transparent,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedSimType = "unsafe" }
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "Unwanted Image",
                                color = if (selectedSimType == "unsafe") AlertRed else TextLight,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            isSimulating = true
                            simulationLogs.clear()
                            coroutineScope.launch {
                                simulationLogs.add("⚡ [Simulator] Booting local pixel scanner...")
                                delay(400)
                                simulationLogs.add("📸 [Simulator] Simulating device screen capture...")
                                delay(500)
                                simulationLogs.add("🧬 [Simulator] Analyzing pixels via GazeGuard AI...")
                                delay(600)
                                if (selectedSimType == "unsafe") {
                                    simulationLogs.add("🚨 [Simulator] DETECTED: Female visual on screen!")
                                    delay(300)
                                    simulationLogs.add("🔒 [Simulator] TRIGGERED: Instantly closing active app!")
                                    delay(400)
                                    
                                    // Increment stats
                                    prefs.edit().putInt("total_blocks", totalBlocks + 1).apply()
                                    prefs.edit().putInt("total_scans", totalScans + 1).apply()
                                    totalBlocks += 1
                                    totalScans += 1

                                    // Add to Room
                                    repository.insert(
                                        BlockLog(
                                            appPackage = "com.android.chrome",
                                            appName = "Chrome (Simulator)",
                                            reason = "Simulated test: Unwanted female imagery detected on social media.",
                                            confidence = 0.98
                                        )
                                    )

                                    Toast.makeText(context, "🛡️ GazeGuard AI: Unwanted content shielded!", Toast.LENGTH_SHORT).show()

                                    // Minimize App
                                    val startMain = Intent(Intent.ACTION_MAIN).apply {
                                        addCategory(Intent.CATEGORY_HOME)
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    context.startActivity(startMain)
                                } else {
                                    simulationLogs.add("✅ [Simulator] Screen safe. No intervention needed.")
                                    prefs.edit().putInt("total_scans", totalScans + 1).apply()
                                    totalScans += 1
                                }
                                isSimulating = false
                            }
                        },
                        enabled = !isSimulating,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("simulate_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = GuardBlue),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isSimulating) "Scanning Screen..." else "Simulate Live Screen Check",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    if (simulationLogs.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SlateBackground)
                                .border(1.dp, Color.DarkGray, RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                simulationLogs.forEach { log ->
                                    Text(
                                        text = log,
                                        fontSize = 11.sp,
                                        color = if (log.contains("🚨") || log.contains("🔒")) AlertRed else if (log.contains("✅")) GreenActive else TextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 8. Block History List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Shield Activity History",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextLight
                )
                if (blockLogs.isNotEmpty()) {
                    Text(
                        text = "Clear Logs",
                        fontSize = 13.sp,
                        color = AlertRed,
                        modifier = Modifier
                            .clickable {
                                coroutineScope.launch {
                                    repository.clear()
                                    prefs.edit().putInt("total_blocks", 0).apply()
                                    prefs.edit().putInt("total_scans", 0).apply()
                                    totalBlocks = 0
                                    totalScans = 0
                                    Toast.makeText(context, "History cleared.", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .testTag("clear_logs_button")
                    )
                }
            }
        }

        if (blockLogs.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SlateCard)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.SafetyCheck,
                            contentDescription = "Safe Shield Icon",
                            tint = Color.Gray,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Your sight is perfectly shielded.",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = TextLight,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "No shield intervention logs yet. Tap the simulator above to run a test scan.",
                            fontSize = 11.sp,
                            color = TextMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(blockLogs) { log ->
                BlockLogItem(log)
            }
        }
    }
}

@Composable
fun BlockLogItem(log: BlockLog) {
    val sdf = remember { SimpleDateFormat("MMM dd, yyyy - hh:mm:ss a", Locale.getDefault()) }
    val timeString = remember(log.timestamp) { sdf.format(Date(log.timestamp)) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SlateCard)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(AlertRed.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Shield Icon",
                            tint = AlertRed,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = log.appName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextLight
                        )
                        Text(
                            text = log.appPackage,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(AlertRed.copy(alpha = 0.2f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Blocked",
                        fontSize = 11.sp,
                        color = AlertRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Reason: ${log.reason}",
                fontSize = 13.sp,
                color = TextLight
            )
            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = Color.DarkGray.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = timeString, fontSize = 11.sp, color = TextMuted)
                Text(
                    text = "AI Match: ${(log.confidence * 100).toInt()}%",
                    fontSize = 11.sp,
                    color = GuardBlue,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val expectedServiceName = ComponentName(context, GazeGuardAccessibilityService::class.java)
    val enabledServices = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    val colonSplitter = TextUtils.SimpleStringSplitter(':')
    colonSplitter.setString(enabledServices)
    while (colonSplitter.hasNext()) {
        val enabledService = colonSplitter.next()
        val enabledComponent = ComponentName.unflattenFromString(enabledService)
        if (enabledComponent != null && enabledComponent == expectedServiceName) {
            return true
        }
    }
    return false
}
