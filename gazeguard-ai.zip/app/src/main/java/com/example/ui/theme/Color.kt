package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GuardBlue = Color(0xFF2A86FF)
val GuardBlueDark = Color(0xFF0052D4)
val SlateBackground = Color(0xFF0F172A)
val SlateCard = Color(0xFF1E293B)
val AlertRed = Color(0xFFEF4444)
val TextLight = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
val GreenActive = Color(0xFF10B981)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

