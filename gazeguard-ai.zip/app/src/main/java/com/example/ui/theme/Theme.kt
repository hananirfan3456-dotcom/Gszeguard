package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = GuardBlue,
    onPrimary = Color.White,
    secondary = SlateCard,
    onSecondary = TextLight,
    tertiary = AlertRed,
    background = SlateBackground,
    onBackground = TextLight,
    surface = SlateCard,
    onSurface = TextLight
  )

private val LightColorScheme =
  lightColorScheme(
    primary = GuardBlue,
    onPrimary = Color.White,
    secondary = SlateCard,
    onSecondary = TextLight,
    tertiary = AlertRed,
    background = SlateBackground,
    onBackground = TextLight,
    surface = SlateCard,
    onSurface = TextLight
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = true,
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
