package com.example.data

import android.content.Context
import androidx.room.Room

object DatabaseProvider {
    @Volatile
    private var database: AppDatabase? = null
    
    private var repository: BlockLogRepository? = null

    fun getDatabase(context: Context): AppDatabase {
        return database ?: synchronized(this) {
            val instance = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "gazeguard_database"
            )
            .fallbackToDestructiveMigration()
            .build()
            database = instance
            instance
        }
    }

    fun getRepository(context: Context): BlockLogRepository {
        return repository ?: synchronized(this) {
            val repo = BlockLogRepository(getDatabase(context).blockLogDao())
            repository = repo
            repo
        }
    }
}
