package com.example.data

import kotlinx.coroutines.flow.Flow

class BlockLogRepository(private val blockLogDao: BlockLogDao) {
    val allLogs: Flow<List<BlockLog>> = blockLogDao.getAllLogs()

    suspend fun insert(log: BlockLog) {
        blockLogDao.insertLog(log)
    }

    suspend fun clear() {
        blockLogDao.clearAllLogs()
    }

    suspend fun getLogCount(): Int {
        return blockLogDao.getLogCount()
    }
}
