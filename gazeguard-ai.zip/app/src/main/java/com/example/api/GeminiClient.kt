package com.example.api

import android.graphics.Bitmap
import android.os.Build
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    // Data classes for request mapping
    data class InlineData(val mimeType: String, val data: String)
    data class GeminiPart(val text: String? = null, val inlineData: InlineData? = null)
    data class GeminiContent(val parts: List<GeminiPart>)
    data class GeminiRequest(val contents: List<GeminiContent>)

    // Data classes for response mapping
    data class GeminiPartResponse(val text: String?)
    data class GeminiContentResponse(val parts: List<GeminiPartResponse>?)
    data class GeminiCandidate(val content: GeminiContentResponse?)
    data class GeminiResponse(val candidates: List<GeminiCandidate>?)

    // Core target result class
    data class DetectionResult(val detected: Boolean, val confidence: Double, val reason: String)

    private val requestAdapter = moshi.adapter(GeminiRequest::class.java)
    private val responseAdapter = moshi.adapter(GeminiResponse::class.java)
    private val detectionResultAdapter = moshi.adapter(DetectionResult::class.java)

    /**
     * Resizes a bitmap to save memory and network bandwidth.
     */
    private fun getResizedBitmap(image: Bitmap, maxSize: Int): Bitmap {
        var width = image.width
        var height = image.height
        val bitmapRatio = width.toFloat() / height.toFloat()
        if (bitmapRatio > 1) {
            width = maxSize
            height = (width / bitmapRatio).toInt()
        } else {
            height = maxSize
            width = (height * bitmapRatio).toInt()
        }
        return Bitmap.createScaledBitmap(image, width, height, true)
    }

    /**
     * Compresses the bitmap to JPEG and returns it as a Base64 string.
     */
    private fun bitmapToBase64(bitmap: Bitmap): String {
        val isHardware = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            bitmap.config == Bitmap.Config.HARDWARE
        } else {
            false
        }
        val softwareBitmap = if (isHardware) {
            bitmap.copy(Bitmap.Config.ARGB_8888, false)
        } else {
            bitmap
        }
        val resized = getResizedBitmap(softwareBitmap, 450) // Resized to small width to scan extremely fast
        val outputStream = ByteArrayOutputStream()
        resized.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
        val byteArray = outputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.NO_WRAP)
    }

    private fun cleanMarkdownJson(raw: String): String {
        var clean = raw.trim()
        if (clean.startsWith("```json")) {
            clean = clean.substringAfter("```json")
        } else if (clean.startsWith("```")) {
            clean = clean.substringAfter("```")
        }
        if (clean.endsWith("```")) {
            clean = clean.substringBeforeLast("```")
        }
        return clean.trim()
    }

    suspend fun analyzeScreenshot(bitmap: Bitmap): DetectionResult {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e(TAG, "Gemini API key is default or empty!")
            return DetectionResult(false, 0.0, "API key not configured in Secrets.")
        }

        val url = "$BASE_URL?key=$apiKey"
        val base64Image = try {
            bitmapToBase64(bitmap)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to encode bitmap: ${e.message}")
            return DetectionResult(false, 0.0, "Error encoding image: ${e.message}")
        }

        val prompt = """
            Analyze this mobile device screen capture. 
            Determine if there is any visible female human being (including baby girl, little girl, young woman, mature woman, or elderly female) or a "she-male" (transgender female) present anywhere in the image. 
            Also check for female cartoon characters, illustrations, animated characters, or drawings that are female.
            If a female or she-male is visible, set "detected" to true.
            
            You must return a strictly valid JSON response ONLY. Do not write any normal text outside the JSON.
            JSON Format:
            {
              "detected": true/false,
              "confidence": 0.0 to 1.0,
              "reason": "Brief English description explaining what was found or why it is safe."
            }
        """.trimIndent()

        val requestPayload = GeminiRequest(
            contents = listOf(
                GeminiContent(
                    parts = listOf(
                        GeminiPart(text = prompt),
                        GeminiPart(inlineData = InlineData(mimeType = "image/jpeg", data = base64Image))
                    )
                )
            )
        )

        val requestJson = requestAdapter.toJson(requestPayload)
        val requestBody = requestJson.toRequestBody("application/json".toMediaTypeOrNull())

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errMsg = "HTTP Error ${response.code}: ${response.message}"
                    Log.e(TAG, errMsg)
                    return DetectionResult(false, 0.0, errMsg)
                }

                val responseBody = response.body?.string() ?: return DetectionResult(false, 0.0, "Empty API Response")
                val geminiResponse = responseAdapter.fromJson(responseBody)
                val rawText = geminiResponse?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    ?: return DetectionResult(false, 0.0, "Invalid JSON structure from Gemini")

                val cleanJson = cleanMarkdownJson(rawText)
                Log.d(TAG, "Cleaned JSON from Gemini: $cleanJson")

                return detectionResultAdapter.fromJson(cleanJson)
                    ?: DetectionResult(false, 0.0, "Could not map JSON: $cleanJson")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Network call failed: ${e.message}", e)
            return DetectionResult(false, 0.0, "Network error: ${e.message}")
        }
    }
}
